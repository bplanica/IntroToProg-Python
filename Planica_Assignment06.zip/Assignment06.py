# ------------------------------------------------- #
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   BPA, 4/23/2019, Added code to complete assignment 5
#   BPA, 5/4/2019, Rearranged existing code to utilize a class and several methods as well as error handling
#                  Completed various aesthetic formatting changes for clearer user interaction, added comments to code
# ------------------------------------------------- #

# -- Data -- # Declare variables and constants
objFileName = "ToDo.txt"  # Relative path, text file must be in the program's file location
strData = ""
dicRow = {}
lstTable = []
strChoice = 0
strMenu = ("""
*************************************
     Menu of Options
     1) Show current data
     2) Add a new item.
     3) Remove an existing item.
     4) Save Data to File
     5) Exit Program
*************************************
     """)


# -- Processing -- #
class ListManager(object):  # Class created to house various interactions with lstTable
    """ This class contains methods for managing a .txt file containing a to do list """

    @staticmethod
    def load_data():
        """Step 1 - Load data from objFileName, referenced in Data"""
        objFile = open(objFileName, "r")  # Open file as read only
        for row in objFile:
            strData = row.split(",")  # Separate items on file by comma (file assumed to be comma delimited)
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}  # Assign values to preset keys
            lstTable.append(dicRow)  # Append existing list with set of dictionary items
        objFile.close()

    @staticmethod
    def view_data():
        """Step 3 - Show the current items in the table"""
        if lstTable == []:  # If the list is empty...
            print("There are currently no items on your ToDo list!")  # ...Inform the user.
        else:
            print("    Task,Priority")  # Print a header line
            print("    --------------")
            for row in lstTable:  # If the list is not empty...
                print("\t" + str(row["Task"]) + "," + str(row["Priority"]))  # Print each row from list to user

    @staticmethod
    def add_data():
        """Step 4 - Add a new item to the list"""
        strData = input("Please enter a task: ").strip()  # Gather task name
        strData2 = input("What is the priority level of this task? ").strip()  # Gather task priority level
        dicRow = {"Task": strData, "Priority": strData2}  # Assign values to preset keys
        lstTable.append(dicRow)  # Append existing list with set of dictionary items
        print("Task added!")

    @staticmethod
    def remove_data():
        """Step 5 - Remove existing item from the list"""
        print("The current list contains:")  # Show current data...
        ListManager.view_data()  # By calling previous method
        print()  # Adding a new line
        strData = input("""Please enter the full Task name for the item you would like to remove.
Press ENTER to return to the main menu. """)  # Gather the user's choice
        blnSwitch = False  # Created switch to notify user if task not found
        if strData == "":  # If the user does not enter a task, exit method by...
            pass  # ...Returning to the presentation loop
        else:
            for row in lstTable:
                if row["Task"].upper() == strData.upper():  # Search each row in lstTable for the full task name
                    lstTable.remove(row)  # Remove task/priority dictionary set from list
                    print("Task removed!")
                    blnSwitch = True  # Marks task as being found
        if blnSwitch == False:  # If task name was not found...
            print("Task was not found - returning to main menu")  # ...Return to the presentation loop

    @staticmethod
    def save_data():
        """Step 6 - Save tasks to objFileName, referenced in Data"""
        objFile = open(objFileName, "w")  # Open file as read/write
        for row in lstTable:
            # Write each dictionary row in lstTable to the text file
            objFile.write(str(row["Task"]) + "," + str(row["Priority"]) + "\n")
        objFile.close()
        print("Data saved to file!")


# -- Presentation -- #
ListManager.load_data()  # Step 1 - Load data from a file

while True:  # Step 2 - Display a menu of choices to the user
    print(strMenu)  # Refers to preset menu declared under Data
    strChoice = str(input("Which option would you like to perform? ")).strip()  # Gathers the user's choice
    print()  # Adding a new line

    if strChoice == "1":  # Step 3 - Show the current items in the table
        ListManager.view_data()
        continue
    elif strChoice == "2":  # Step 4 - Add a new item to the list
        ListManager.add_data()
        continue
    elif strChoice == "3":  # Step 5 - Remove existing item from the list
        ListManager.remove_data()
        continue
    elif strChoice == "4":  # Step 6 - Save tasks to the .txt file
        ListManager.save_data()
        continue
    elif strChoice == "5":  # Step 7 - Exit program
        print("Goodbye!")
        break  # Exit while loop
