# ------------------------------------------------- #
# Title: Error Handling with Python
# Dev:   BPA
# Date:  May 10, 2019
# ChangeLog: (Who, When, What)
#   BPA, 5/10/2019, Created Script Example
# https://docs.python.org/3/library/exceptions.html
# ------------------------------------------------- #

# -- Data -- # Declare variables and constants
objFileName = "ToDo.txt"  # Relative path, text file must be in the program's file location


# -- Processing -- #
class ListManager(object):  # Class created to house various interactions with lstTable
    """ This class contains methods for managing a .txt file containing a to do list """

    @staticmethod
    def load_data(FileName):
        """Step 1 - Load data from FileName"""
        try:
            objFile = open(FileName, "r")  # Open file as read only
            print("ToDo.txt was found in program location!")  # Confirms if the file was located
            objFile.close()  # Close file object
        except FileNotFoundError:  # Returns if FileNotFoundError is thrown
            print("ToDo.txt was NOT found in program location!")  # Confirms if the file was not located
        except Exception as e:
            print("Unexpected error occurred: ")
            print(e)


# -- Presentation -- #
ListManager.load_data(objFileName)  # Load data from a file
