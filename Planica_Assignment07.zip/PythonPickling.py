# ------------------------------------------------- #
# Title: Pickling with Python
# Dev:   BPA
# Date:  May 10, 2019
# ChangeLog: (Who, When, What)
#   BPA, 5/10/2019, Created Script Example
# https://docs.python.org/3/library/pickle.html
# ------------------------------------------------- #

import pickle

# -- Data -- # Declare variables and constants
objFileName = "PickledData.txt"  # Relative path, text file must be in the program's file location
lstData = ["1", "2", "3", "a", "b", "c"]  # Starting data


# -- Processing -- #
class ListManager(object):  # Class created to house various interactions with .txt file
    """ This class contains methods for managing a .txt file"""

    @staticmethod
    def dump_data(Data, FileName):
        """Load Data onto FileName - write binary"""
        objFile = open(FileName, "wb")  # Open file, write binary
        pickle.dump(Data, objFile)  # Dump Data onto file
        objFile.close()  # Close file object

    @staticmethod
    def load_data(FileName):
        """Load data from FileName - read binary"""
        objFile = open(FileName, "rb")  # Open file, read binary
        Data = pickle.load(objFile)  # Load data from file
        objFile.close()  # Close file object
        return Data  # Pass Data back to presentation portion


# -- Presentation -- #
ListManager.dump_data(lstData, objFileName)  # Process dump_data
lstData2 = ListManager.load_data(objFileName)  # Process load_data into new variable
print(lstData2)  # Print data read from loan_data
