# ------------------------------------------------- #
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   BPA, 4/23/2019, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# ------------------------------------------------- #

# -- Data -- #
# Declare variables and constants
# objFile = "ToDo.txt"
strData = ""
dicRow = {}
lstTable = []
strChoice = 0
strMenu = ("""
     Menu of Options
     1) Show current data
     2) Add a new item.
     3) Remove an existing item.
     4) Save Data to File
     5) Exit Program
     """)

# -- Input/Output -- #
# Step 1 - Load data from a file
# Import items from .txt into a dictionary; create a list from entry rows
objFile = open("ToDo.txt", "r")
for row in objFile:
    strData = row.split(",")
    dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dicRow)
objFile.close()

# Step 2 - Display a menu of choices to the user
while True:
    print(strMenu)
    strChoice = str(input("Which option would you like to perform? "))
    print()  # Adding a new line

    # Step 3 -Show the current items in the table
    if strChoice.strip() == "1":
        for row in lstTable:
            print(str(row["Task"]) + "," + str(row["Priority"]))
        continue

    # Step 4 - Add a new item to the list/Table
    elif strChoice.strip() == "2":
        strData = input("Please enter a task: ")
        strData2 = input("What is the priority level of this task? ")
        dicRow = {"Task": strData.strip(), "Priority": strData2.strip()}
        lstTable.append(dicRow)
        print("Task added!")
        continue

    # Step 5 - Remove a new item to the list/Table
    elif strChoice.strip() == "3":
        strData = input("What task would you like to remove? ")
        for row in lstTable:
            if row["Task"].upper() == strData.upper():
                lstTable.remove(row)
        print("Task removed!")
        continue

    # Step 6 - Save tasks to the .txt file
    elif strChoice.strip() == "4":
        objFile = open("ToDo.txt", "w")
        for row in lstTable:
            objFile.write(str(row["Task"]) + "," + str(row["Priority"]) + "\n")
        objFile.close()
        print("Data saved to file!")
        continue

    elif strChoice.strip() == "5":
        print("Goodbye!")
        break  # and Exit the program
